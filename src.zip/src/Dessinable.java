
public interface Dessinable {
	public void dessiner();
}
